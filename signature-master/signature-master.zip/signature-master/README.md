Signature
---


A flutter implementation of drawing app. 
Export image to storage in PNG format.

[![Available on Google Play](https://res.cloudinary.com/vemarav/image/upload/c_scale,w_150/v1547657954/get_it_on_google_play.png)](https://play.google.com/store/apps/details?id=com.vemarav.signature&hl=en)

[![Demo](https://res.cloudinary.com/vemarav/image/upload/c_scale,h_340,w_160/v1547048611/Github/demo.png)](https://www.youtube.com/watch?v=mM2Z-kHjELw)


Implementation
---
Checkout file [signature/lib/main.dart](https://github.com/vemarav/signature/blob/master/lib/main.dart)

Licence
---

[MIT License](https://opensource.org/licenses/MIT)

Author
---

- [Aravind Vemula](https://github.com/vemarav)

Social
---

[![Twitter Follow](https://img.shields.io/twitter/follow/vemarav.svg?style=social&label=Follow)](https://twitter.com/vemarav)

